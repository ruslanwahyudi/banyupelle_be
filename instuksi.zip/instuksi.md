saya ingin mengambil duk_pelayanan by id, 
kemudian duk_pelayanan join dengan duk_jenis_pelayanan by duk_pelayanan id, 
lalu untuk duk_jenis_pelayanan join dengan duk_identitas_pemohon, juga join dengan duk_syarat_dokumen, 
untuk tiap data duk_identitas_pemohon pemohon, saya ingin mengambil data dari duk_data_identitas_pemohon
untuk tiap data duk_syarat_dokumen, saya ingin mengambil data dari duk_dokumen_pengajuan
buatkan query untuk mengambil data tersebut